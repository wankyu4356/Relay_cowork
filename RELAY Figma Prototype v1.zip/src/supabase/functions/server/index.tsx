import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use('*', logger(console.log));

app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "apikey", "x-user-token"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Helper: get authenticated user from request
async function getAuthUser(c: any) {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  // Prefer x-user-token (custom header that bypasses gateway JWT validation).
  // Fall back to Authorization header for backwards compat.
  let accessToken = c.req.header('x-user-token') || '';
  if (!accessToken) {
    const authHeader = c.req.header('Authorization') || '';
    accessToken = authHeader.split(' ')[1] || '';
  }

  if (!accessToken) {
    console.log('getAuthUser: No access token found in x-user-token or Authorization header');
    return null;
  }

  const { data, error } = await supabase.auth.getUser(accessToken);
  if (error) {
    console.log(`getAuthUser: auth.getUser failed — ${error.message}`);
    return null;
  }
  if (!data?.user?.id) {
    console.log('getAuthUser: No user id in response');
    return null;
  }
  return data.user;
}

// Helper: generate unique ID
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ============================
// Health Check
// ============================
app.get("/make-server-370ee075/health", (c) => {
  return c.json({ status: "ok" });
});

// ============================
// AUTH: Sign Up
// ============================
app.post("/make-server-370ee075/auth/signup", async (c) => {
  try {
    const { email, password, name, role } = await c.req.json();
    if (!email || !password || !name) {
      return c.json({ error: "이메일, 비밀번호, 이름은 필수입니다." }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role: role || 'mentee' },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.log(`Auth signup error: ${error.message}`);
      return c.json({ error: `회원가입 실패: ${error.message}` }, 400);
    }

    const userId = data.user.id;
    const userRole = role || 'mentee';

    // Create user profile in KV
    await kv.set(`user:${userId}`, {
      id: userId,
      email,
      name,
      role: userRole,
      createdAt: new Date().toISOString(),
      onboardingCompleted: false,
      profile: {},
    });

    // Initialize credits
    await kv.set(`credits:${userId}`, { balance: 5 });

    console.log(`User created successfully: ${userId}, role: ${userRole}`);
    return c.json({ success: true, userId, role: userRole });
  } catch (e) {
    console.log(`Signup handler error: ${e}`);
    return c.json({ error: `서버 오류: ${e}` }, 500);
  }
});

// ============================
// PROFILE: Get Profile
// ============================
app.get("/make-server-370ee075/profile", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const profile = await kv.get(`user:${user.id}`);
    const credits = await kv.get(`credits:${user.id}`);
    
    return c.json({
      profile: profile || {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name || '사용자',
        role: user.user_metadata?.role || 'mentee',
        createdAt: new Date().toISOString(),
        onboardingCompleted: false,
        profile: {},
      },
      credits: credits?.balance ?? 5,
    });
  } catch (e) {
    console.log(`Get profile error: ${e}`);
    return c.json({ error: `프로필 조회 실패: ${e}` }, 500);
  }
});

// ============================
// PROFILE: Update Profile
// ============================
app.put("/make-server-370ee075/profile", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const updates = await c.req.json();
    const existing = await kv.get(`user:${user.id}`) || {};
    
    const updated = {
      ...existing,
      ...updates,
      id: user.id,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`user:${user.id}`, updated);
    return c.json({ success: true, profile: updated });
  } catch (e) {
    console.log(`Update profile error: ${e}`);
    return c.json({ error: `프로필 업데이트 실패: ${e}` }, 500);
  }
});

// ============================
// CREDITS: Get Balance
// ============================
app.get("/make-server-370ee075/credits", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const credits = await kv.get(`credits:${user.id}`);
    return c.json({ balance: credits?.balance ?? 5 });
  } catch (e) {
    console.log(`Get credits error: ${e}`);
    return c.json({ error: `크레딧 조회 실패: ${e}` }, 500);
  }
});

// ============================
// CREDITS: Use Credit
// ============================
app.post("/make-server-370ee075/credits/use", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const { amount } = await c.req.json();
    const credits = await kv.get(`credits:${user.id}`);
    const currentBalance = credits?.balance ?? 5;
    
    if (currentBalance < (amount || 1)) {
      return c.json({ error: "크레딧이 부족합니다." }, 400);
    }

    const newBalance = currentBalance - (amount || 1);
    await kv.set(`credits:${user.id}`, { balance: newBalance });

    // Log transaction
    const txId = genId();
    await kv.set(`credit_tx:${user.id}:${txId}`, {
      id: txId,
      userId: user.id,
      type: 'use',
      amount: amount || 1,
      balanceAfter: newBalance,
      createdAt: new Date().toISOString(),
    });

    return c.json({ success: true, balance: newBalance });
  } catch (e) {
    console.log(`Use credit error: ${e}`);
    return c.json({ error: `크레딧 사용 실패: ${e}` }, 500);
  }
});

// ============================
// CREDITS: Add Credits (Purchase)
// ============================
app.post("/make-server-370ee075/credits/add", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const { amount } = await c.req.json();
    const credits = await kv.get(`credits:${user.id}`);
    const currentBalance = credits?.balance ?? 0;
    const newBalance = currentBalance + (amount || 1);
    
    await kv.set(`credits:${user.id}`, { balance: newBalance });

    const txId = genId();
    await kv.set(`credit_tx:${user.id}:${txId}`, {
      id: txId,
      userId: user.id,
      type: 'add',
      amount: amount || 1,
      balanceAfter: newBalance,
      createdAt: new Date().toISOString(),
    });

    return c.json({ success: true, balance: newBalance });
  } catch (e) {
    console.log(`Add credit error: ${e}`);
    return c.json({ error: `크레딧 추가 실패: ${e}` }, 500);
  }
});

// ============================
// DRAFTS: List User's Drafts
// ============================
app.get("/make-server-370ee075/drafts", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const drafts = await kv.getByPrefix(`draft:${user.id}:`);
    // Sort by updatedAt descending
    drafts.sort((a: any, b: any) => 
      new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime()
    );
    return c.json({ drafts });
  } catch (e) {
    console.log(`Get drafts error: ${e}`);
    return c.json({ error: `초안 목록 조회 실패: ${e}` }, 500);
  }
});

// ============================
// DRAFTS: Create Draft
// ============================
app.post("/make-server-370ee075/drafts", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const body = await c.req.json();
    const draftId = genId();
    
    const draft = {
      id: draftId,
      userId: user.id,
      university: body.university || '',
      major: body.major || '',
      content: body.content || '',
      storyline: body.storyline || null,
      aiData: body.aiData || null,
      wordCount: body.content?.length || 0,
      version: 1,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`draft:${user.id}:${draftId}`, draft);
    return c.json({ success: true, draft });
  } catch (e) {
    console.log(`Create draft error: ${e}`);
    return c.json({ error: `초안 저장 실패: ${e}` }, 500);
  }
});

// ============================
// DRAFTS: Update Draft
// ============================
app.put("/make-server-370ee075/drafts/:id", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const draftId = c.req.param('id');
    const existing = await kv.get(`draft:${user.id}:${draftId}`);
    if (!existing) return c.json({ error: "초안을 찾을 수 없습니다." }, 404);

    const updates = await c.req.json();
    const updated = {
      ...existing,
      ...updates,
      id: draftId,
      userId: user.id,
      version: (existing.version || 1) + 1,
      wordCount: updates.content?.length || existing.wordCount,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`draft:${user.id}:${draftId}`, updated);
    return c.json({ success: true, draft: updated });
  } catch (e) {
    console.log(`Update draft error: ${e}`);
    return c.json({ error: `초안 업데이트 실패: ${e}` }, 500);
  }
});

// ============================
// DRAFTS: Delete Draft
// ============================
app.delete("/make-server-370ee075/drafts/:id", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const draftId = c.req.param('id');
    await kv.del(`draft:${user.id}:${draftId}`);
    return c.json({ success: true });
  } catch (e) {
    console.log(`Delete draft error: ${e}`);
    return c.json({ error: `초안 삭제 실패: ${e}` }, 500);
  }
});

// ============================
// SESSIONS: List Sessions
// ============================
app.get("/make-server-370ee075/sessions", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const sessions = await kv.getByPrefix(`session:${user.id}:`);
    sessions.sort((a: any, b: any) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return c.json({ sessions });
  } catch (e) {
    console.log(`Get sessions error: ${e}`);
    return c.json({ error: `세션 조회 실패: ${e}` }, 500);
  }
});

// ============================
// SESSIONS: Book Session
// ============================
app.post("/make-server-370ee075/sessions", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const body = await c.req.json();
    const sessionId = genId();

    const session = {
      id: sessionId,
      userId: user.id,
      mentorId: body.mentorId,
      mentorName: body.mentorName,
      mentorAvatar: body.mentorAvatar || '',
      date: body.date,
      time: body.time,
      duration: body.duration || 60,
      price: body.price || 0,
      status: 'upcoming',
      topic: body.topic || '',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`session:${user.id}:${sessionId}`, session);

    // Also store for mentor side
    if (body.mentorId) {
      await kv.set(`mentor_session:${body.mentorId}:${sessionId}`, session);
    }

    return c.json({ success: true, session });
  } catch (e) {
    console.log(`Book session error: ${e}`);
    return c.json({ error: `세션 예약 실패: ${e}` }, 500);
  }
});

// ============================
// SESSIONS: Update Session Status
// ============================
app.put("/make-server-370ee075/sessions/:id", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const sessionId = c.req.param('id');
    const existing = await kv.get(`session:${user.id}:${sessionId}`);
    if (!existing) return c.json({ error: "세션을 찾을 수 없습니다." }, 404);

    const updates = await c.req.json();
    const updated = { ...existing, ...updates, updatedAt: new Date().toISOString() };
    await kv.set(`session:${user.id}:${sessionId}`, updated);

    return c.json({ success: true, session: updated });
  } catch (e) {
    console.log(`Update session error: ${e}`);
    return c.json({ error: `세션 업데이트 실패: ${e}` }, 500);
  }
});

// ============================
// REVIEWS: Submit Review
// ============================
app.post("/make-server-370ee075/reviews", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const body = await c.req.json();
    const reviewId = genId();

    const review = {
      id: reviewId,
      userId: user.id,
      mentorId: body.mentorId,
      sessionId: body.sessionId,
      rating: body.rating,
      content: body.content,
      tags: body.tags || [],
      createdAt: new Date().toISOString(),
    };

    await kv.set(`review:${body.mentorId}:${reviewId}`, review);
    await kv.set(`user_review:${user.id}:${reviewId}`, review);

    return c.json({ success: true, review });
  } catch (e) {
    console.log(`Submit review error: ${e}`);
    return c.json({ error: `리뷰 작성 실패: ${e}` }, 500);
  }
});

// ============================
// REVIEWS: Get Mentor Reviews
// ============================
app.get("/make-server-370ee075/reviews/:mentorId", async (c) => {
  try {
    const mentorId = c.req.param('mentorId');
    const reviews = await kv.getByPrefix(`review:${mentorId}:`);
    reviews.sort((a: any, b: any) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return c.json({ reviews });
  } catch (e) {
    console.log(`Get reviews error: ${e}`);
    return c.json({ error: `리뷰 조회 실패: ${e}` }, 500);
  }
});

// ============================
// MENTORS: List Mentors
// ============================
app.get("/make-server-370ee075/mentors", async (c) => {
  try {
    const mentors = await kv.getByPrefix('mentor_profile:');
    return c.json({ mentors });
  } catch (e) {
    console.log(`Get mentors error: ${e}`);
    return c.json({ error: `멘토 목록 조회 실패: ${e}` }, 500);
  }
});

// ============================
// MENTORS: Register as Mentor
// ============================
app.post("/make-server-370ee075/mentors/register", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const body = await c.req.json();
    
    const mentorProfile = {
      id: user.id,
      name: body.name || user.user_metadata?.name || '멘토',
      email: user.email,
      university: body.university,
      major: body.major,
      year: body.year,
      rating: 0,
      reviews: 0,
      sessions: 0,
      successRate: 0,
      responseTime: body.responseTime || '2시간',
      price: body.price || 30000,
      badge: 'bronze',
      verified: false,
      avatar: body.avatar || '👨‍🎓',
      expertise: body.expertise || [],
      bio: body.bio || '',
      createdAt: new Date().toISOString(),
    };

    await kv.set(`mentor_profile:${user.id}`, mentorProfile);

    // Update user role
    const userProfile = await kv.get(`user:${user.id}`) || {};
    await kv.set(`user:${user.id}`, { ...userProfile, role: 'mentor' });

    return c.json({ success: true, mentor: mentorProfile });
  } catch (e) {
    console.log(`Register mentor error: ${e}`);
    return c.json({ error: `멘토 등록 실패: ${e}` }, 500);
  }
});

// ============================
// NOTIFICATIONS: Get Notifications
// ============================
app.get("/make-server-370ee075/notifications", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const notifications = await kv.getByPrefix(`notif:${user.id}:`);
    notifications.sort((a: any, b: any) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return c.json({ notifications });
  } catch (e) {
    console.log(`Get notifications error: ${e}`);
    return c.json({ error: `알림 조회 실패: ${e}` }, 500);
  }
});

// ============================
// NOTIFICATIONS: Mark Read
// ============================
app.put("/make-server-370ee075/notifications/:id/read", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const notifId = c.req.param('id');
    const existing = await kv.get(`notif:${user.id}:${notifId}`);
    if (existing) {
      await kv.set(`notif:${user.id}:${notifId}`, { ...existing, read: true });
    }
    return c.json({ success: true });
  } catch (e) {
    console.log(`Mark notification read error: ${e}`);
    return c.json({ error: `알림 읽음 처리 실패: ${e}` }, 500);
  }
});

// ============================
// MESSAGES: Send Message
// ============================
app.post("/make-server-370ee075/messages", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const body = await c.req.json();
    const msgId = genId();
    const convId = body.conversationId || [user.id, body.recipientId].sort().join('_');

    const message = {
      id: msgId,
      conversationId: convId,
      senderId: user.id,
      recipientId: body.recipientId,
      content: body.content,
      createdAt: new Date().toISOString(),
      read: false,
    };

    await kv.set(`msg:${convId}:${msgId}`, message);

    // Update conversation metadata for both users
    const convMeta = {
      id: convId,
      lastMessage: body.content,
      lastMessageAt: new Date().toISOString(),
      participants: [user.id, body.recipientId],
    };
    await kv.set(`conv:${user.id}:${convId}`, convMeta);
    await kv.set(`conv:${body.recipientId}:${convId}`, convMeta);

    return c.json({ success: true, message });
  } catch (e) {
    console.log(`Send message error: ${e}`);
    return c.json({ error: `메시지 전송 실패: ${e}` }, 500);
  }
});

// ============================
// MESSAGES: Get Conversations
// ============================
app.get("/make-server-370ee075/conversations", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const conversations = await kv.getByPrefix(`conv:${user.id}:`);
    conversations.sort((a: any, b: any) =>
      new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
    );
    return c.json({ conversations });
  } catch (e) {
    console.log(`Get conversations error: ${e}`);
    return c.json({ error: `대화 목록 조회 실패: ${e}` }, 500);
  }
});

// ============================
// MESSAGES: Get Messages in Conversation
// ============================
app.get("/make-server-370ee075/messages/:conversationId", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    const convId = c.req.param('conversationId');
    const messages = await kv.getByPrefix(`msg:${convId}:`);
    messages.sort((a: any, b: any) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
    return c.json({ messages });
  } catch (e) {
    console.log(`Get messages error: ${e}`);
    return c.json({ error: `메시지 조회 실패: ${e}` }, 500);
  }
});

// ============================
// ADMIN: Platform Stats
// ============================
app.get("/make-server-370ee075/admin/stats", async (c) => {
  try {
    const user = await getAuthUser(c);
    if (!user) return c.json({ error: "인증 필요" }, 401);

    // Get user profile to verify admin role
    const profile = await kv.get(`user:${user.id}`);
    if (profile?.role !== 'admin') {
      return c.json({ error: "관리자 권한 필요" }, 403);
    }

    const mentors = await kv.getByPrefix('mentor_profile:');
    const allUsers = await kv.getByPrefix('user:');

    return c.json({
      totalUsers: allUsers.length,
      totalMentors: mentors.length,
      activeMentors: mentors.filter((m: any) => m.verified).length,
    });
  } catch (e) {
    console.log(`Admin stats error: ${e}`);
    return c.json({ error: `통계 조회 실패: ${e}` }, 500);
  }
});

Deno.serve(app.fetch);